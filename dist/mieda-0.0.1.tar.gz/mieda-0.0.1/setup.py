from setuptools import setup

setup(
    name='mieda',
    packages=['mieda'],
    version='0.0.1',
    description='',
    author='Valentino Constantinou',
    author_email='vconstan@jpl.caltech.edu',
    # url='https://github.com/vc1492a/mieda',
    # download_url='https://github.com/vc1492a/mieda/archive/0.0.1.tar.gz',
    keywords=[],
    classifiers=[],
    license='Apache License, Version 2.0',
    install_requires=[]
)